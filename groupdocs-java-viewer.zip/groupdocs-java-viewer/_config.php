<?php


ShortcodeParser::get('default')->register('groupdocsJavaViewer', array('groupdocsJavaViewer', 'handle_shortcode'));
